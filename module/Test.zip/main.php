<?php

class Test {
	function __construct() {
		echo "It works!";
	}
}

?>
